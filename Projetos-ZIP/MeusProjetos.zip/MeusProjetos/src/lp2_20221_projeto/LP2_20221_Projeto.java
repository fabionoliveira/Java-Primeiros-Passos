
package lp2_20221_projeto;


public class LP2_20221_Projeto {

    
    public static void main(String[] args) {
       
    }
    
}
