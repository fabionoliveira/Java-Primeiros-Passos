/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herancateste2;

/**
 *
 * @author FO
 */
public class HerancaTeste2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        A x1 = new A();
        B x2 = new B();
        C x3 = new C();
        D x4 = new D();
        E x5 = new E();
        
        x5.a1();
        x5.a2();
        x5.a3();
        x5.a4();
        x5.a5();
        
    }
    
}
