/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herancateste2;

/**
 *
 * @author FO
 */
public class C extends B{
    public void a2(){
        System.out.println("C.a2");
    }public void a5(){
        System.out.println("C.a5");
    }
}
