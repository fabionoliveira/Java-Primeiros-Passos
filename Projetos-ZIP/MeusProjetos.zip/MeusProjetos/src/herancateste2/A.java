/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herancateste2;

/**
 *
 * @author FO
 */
public class A {
    public void a1(){
        System.out.println("A.a1");
    }public void a2(){
        System.out.println("A.a2");
    }public void a3(){
        System.out.println("A.a3");
    }public void a4(){
        System.out.println("A.a4");
    }
}
