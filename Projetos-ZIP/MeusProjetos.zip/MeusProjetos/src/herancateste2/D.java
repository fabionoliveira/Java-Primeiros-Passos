/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herancateste2;

/**
 *
 * @author FO
 */
public class D extends C{
    public void a4(){
        System.out.println("D.a4");
    }
}
