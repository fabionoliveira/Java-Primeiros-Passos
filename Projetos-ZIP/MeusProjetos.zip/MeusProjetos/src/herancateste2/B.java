/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herancateste2;

/**
 *
 * @author FO
 */
public class B extends A{
    public void a2(){
        System.out.println("B.a2");
    }public void a4(){
        System.out.println("B.a4");
    }public void a6(){
        System.out.println("B.a6");
    }
}
