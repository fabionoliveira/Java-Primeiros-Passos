
package heranca_teste;


public class Classek extends ClasseX{
    
    public void m4(){
        System.out.println("K.m4");
    
    }public void m5(){
        System.out.println("K.m5");
    
    }
    
}
