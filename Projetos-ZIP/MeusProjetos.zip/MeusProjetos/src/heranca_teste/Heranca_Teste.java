/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca_teste;

/**
 *
 * @author FO
 */
public class Heranca_Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClasseW w = new ClasseW();
        
        w.m1();
        w.m2();
        w.m3();
        w.m5();
    }
    
}
