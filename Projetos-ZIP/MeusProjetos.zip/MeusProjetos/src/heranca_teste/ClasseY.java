
package heranca_teste;


public class ClasseY extends ClasseX{
    
    public void m1(){
        System.out.println("Y.m1");
    
    }public void m2(){
        System.out.println("Y.m2");
    
    }public void m3(){
        System.out.println("Y.m3");
    
    }
    
}
