
package heranca_teste;


public class ClasseX {
    
    public void m1(){
        System.out.println("X.m1");
    
    }public void m2(){
        System.out.println("X.m2");
    
    }public void m5(){
        System.out.println("X.m5");
    
    }
    
}
