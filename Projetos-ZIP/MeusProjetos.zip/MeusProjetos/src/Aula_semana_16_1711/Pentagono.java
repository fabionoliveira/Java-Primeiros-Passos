/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula_semana_16_1711;

/**
 *
 * @author FO
 */
public class Pentagono extends Figura {

    public void calc_area(double lado) {
        System.out.println("Area do Pentagono!");
    }
}
