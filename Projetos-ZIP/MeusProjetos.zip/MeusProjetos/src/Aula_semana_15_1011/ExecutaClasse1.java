/*
 * EXECUTA CLASSE 1
 * ACHANDO O MAIOR E MENOR VALOR DE UM VETOR
 */
package Aula_semana_15_1011;

/**
 *
 * @author FO
 */
public class ExecutaClasse1 extends Classe1 
{
    public static void main(String[] args) 
    {
        ExecutaClasse1 obj = new ExecutaClasse1();
        obj.controle();
    }
}