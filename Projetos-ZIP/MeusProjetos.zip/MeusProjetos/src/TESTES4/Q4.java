/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TESTES4;

import java.util.ArrayList;

/**
 *
 * @author FO
 */
public class Q4 {

    public static void main(String[] args) {
        
        /*
        Sobre ArrayList, qual a forma correta de se declarar uma ArrayList 
        de números inteiros que irá armazernar 10 elementos? O Nome da ArrayList
        é Prova. Leitura Avançada
        (1 Ponto)
        */
        
        ArrayList<Integer> Prova = new ArrayList(); // É essa aqui

        // ArrayList<int> Prova = new ArrayList(10);

       //  ArrayList<Integer> Prova = new ArrayList[10];

       //  ArrayList<int> Prova = new ArrayList(10);

        //ArrayList<int> Prova = new ArrayList[10];
        
        
    }

}
