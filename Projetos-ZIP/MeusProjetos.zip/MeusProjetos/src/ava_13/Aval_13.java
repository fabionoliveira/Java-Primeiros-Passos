package ava_13;

import java.util.Scanner;


public class Aval_13 {
   
  public int N;

  public void Leitura(){
      Scanner leitor = new Scanner(System.in);
      System.out.println("Digite um valor: ");
      N = leitor.nextInt();
  }
}
