/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg1;

/**
 *
 * @author FO
 */
public class Tab_Cidade extends Tab_Funcionario{
    private int cod_cidade;
    private String nm_cidade;
    private String abr_cidade;
    private String ds_uf;

    public int getCod_cidade() {
        return cod_cidade;
    }

    public void setCod_cidade(int cod_cidade) {
        this.cod_cidade = cod_cidade;
    }

    public String getNm_cidade() {
        return nm_cidade;
    }

    public void setNm_cidade(String nm_cidade) {
        this.nm_cidade = nm_cidade;
    }

    public String getAbr_cidade() {
        return abr_cidade;
    }

    public void setAbr_cidade(String abr_cidade) {
        this.abr_cidade = abr_cidade;
    }

    public String getDs_uf() {
        return ds_uf;
    }

    public void setDs_uf(String ds_uf) {
        this.ds_uf = ds_uf;
    }
    
    
    
}
