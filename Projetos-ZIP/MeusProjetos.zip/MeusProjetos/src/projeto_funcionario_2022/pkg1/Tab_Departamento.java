/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg1;

/**
 *
 * @author FO
 */
public class Tab_Departamento {
    
    private int cod_Departamento;
    private String nm_Departamento;
    private String si_Departamento;
    private boolean is_Gerente;

    public int getCod_Departamento() {
        return cod_Departamento;
    }

    public void setCod_Departamento(int cod_Departamento) {
        this.cod_Departamento = cod_Departamento;
    }

    public String getNm_Departamento() {
        return nm_Departamento;
    }

    public void setNm_Departamento(String nm_Departamento) {
        this.nm_Departamento = nm_Departamento;
    }

    public String getSi_Departamento() {
        return si_Departamento;
    }

    public void setSi_Departamento(String si_Departamento) {
        this.si_Departamento = si_Departamento;
    }

    public boolean isIs_Gerente() {
        return is_Gerente;
    }

    public void setIs_Gerente(boolean is_Gerente) {
        this.is_Gerente = is_Gerente;
    }
    
    
}
