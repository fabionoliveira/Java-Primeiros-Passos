/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg1;

/**
 *
 * @author FO
 */
public class Tab_Dependente extends Tab_Funcionario{
    
    private int cod_Dependente;
    //private String nm_Funcionario;
    private String nm_Dependente;
    private String dt_NasDependente;
    //private String rg_Dependente;
   // private String cpf_Dependente;
    private String gen_Dependente;
    private String grau_Dependente;
        
    
    
}
