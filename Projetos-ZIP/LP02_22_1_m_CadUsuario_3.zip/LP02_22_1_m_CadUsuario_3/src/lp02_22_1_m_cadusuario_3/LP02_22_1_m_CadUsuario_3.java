
package lp02_22_1_m_cadusuario_3;


public class LP02_22_1_m_CadUsuario_3 {

   
    public static void main(String[] args) {
        
        fr_CadUsuario_2   myTela = new  fr_CadUsuario_2 ();
        
        myTela.setVisible(true);
        
        
        /*
        Tab_Usuario  usr = new Tab_Usuario ();
        
        usr.setId_usuario(10);
        usr.setNm_Usuario("Zé");
        usr.setDs_TpUsuario("ADM");
        usr.setDs_LoginUsuario("ZEZE");
        usr.setIs_Permitido_CD(true);
        usr.setIs_Permitido_PE(true);
        usr.setIs_Permitido_RA(true);
        usr.setIs_Permitido_RG(true);
        usr.setDs_Genero("M");
        */
        
        
        
        
        
        
        
        
        
    }
    
}
