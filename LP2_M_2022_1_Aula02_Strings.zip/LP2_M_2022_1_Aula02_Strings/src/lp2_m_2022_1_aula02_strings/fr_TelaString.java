
package lp2_m_2022_1_aula02_strings;

import javax.swing.JOptionPane;

public class fr_TelaString extends javax.swing.JFrame {

    public String st1;
    public String st2;
    
    public char c1;
    public char c2;
    
    public String msg;
    
    public fr_TelaString() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        lb_St1 = new javax.swing.JLabel();
        lb_St2 = new javax.swing.JLabel();
        tf_St1 = new javax.swing.JTextField();
        tf_St2 = new javax.swing.JTextField();
        bt_Equals = new javax.swing.JButton();
        bt_EqualsIgnoreCase = new javax.swing.JButton();
        bt_isEmpty = new javax.swing.JButton();
        bt_toUpperCase = new javax.swing.JButton();
        bt_toLowerCase = new javax.swing.JButton();
        bt_EndsWith = new javax.swing.JButton();
        bt_StartsWith1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        bt_Replace = new javax.swing.JButton();
        lb_c1 = new javax.swing.JLabel();
        lb_c2 = new javax.swing.JLabel();
        tf_c1 = new javax.swing.JTextField();
        tf_c2 = new javax.swing.JTextField();
        bt_IndexOf = new javax.swing.JButton();
        bt_LastIndexOf = new javax.swing.JButton();
        bt_SubString = new javax.swing.JButton();

        jButton2.setText("jButton2");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tela tratamento de String");

        lb_St1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lb_St1.setText("String1:");

        lb_St2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lb_St2.setText("String2:");

        tf_St1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        tf_St2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        bt_Equals.setText("Equals");
        bt_Equals.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_EqualsActionPerformed(evt);
            }
        });

        bt_EqualsIgnoreCase.setText("EqualsIgnoreCase");
        bt_EqualsIgnoreCase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_EqualsIgnoreCaseActionPerformed(evt);
            }
        });

        bt_isEmpty.setText("isEmpty");
        bt_isEmpty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_isEmptyActionPerformed(evt);
            }
        });

        bt_toUpperCase.setText("toUpperCase");
        bt_toUpperCase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_toUpperCaseActionPerformed(evt);
            }
        });

        bt_toLowerCase.setText("toLowerCase");
        bt_toLowerCase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_toLowerCaseActionPerformed(evt);
            }
        });

        bt_EndsWith.setText("EndsWith");
        bt_EndsWith.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_EndsWithActionPerformed(evt);
            }
        });

        bt_StartsWith1.setText("StartsWith");
        bt_StartsWith1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_StartsWith1ActionPerformed(evt);
            }
        });

        jButton1.setText("length");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        bt_Replace.setText("Replace");
        bt_Replace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_ReplaceActionPerformed(evt);
            }
        });

        lb_c1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lb_c1.setText("Caractere1:");

        lb_c2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lb_c2.setText("Caractere2:");

        bt_IndexOf.setText("IndexOf");
        bt_IndexOf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_IndexOfActionPerformed(evt);
            }
        });

        bt_LastIndexOf.setText("LastIndexOf");
        bt_LastIndexOf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_LastIndexOfActionPerformed(evt);
            }
        });

        bt_SubString.setText("SubString(i,f) ");
        bt_SubString.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_SubStringActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lb_St1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tf_St1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(bt_isEmpty, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                    .addComponent(bt_Equals, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(bt_Replace))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addComponent(bt_EqualsIgnoreCase))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(bt_IndexOf, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(bt_toLowerCase, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(bt_toUpperCase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(bt_LastIndexOf, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                .addGap(19, 19, 19)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(bt_StartsWith1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(bt_EndsWith, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(bt_SubString))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lb_St2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tf_St2, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lb_c1)
                            .addComponent(lb_c2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tf_c1)
                            .addComponent(tf_c2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_St1)
                    .addComponent(tf_St1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lb_St2)
                    .addComponent(tf_St2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_c1)
                    .addComponent(tf_c1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_c2)
                    .addComponent(tf_c2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_Equals)
                    .addComponent(bt_EqualsIgnoreCase)
                    .addComponent(bt_StartsWith1)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_isEmpty)
                    .addComponent(bt_toUpperCase)
                    .addComponent(bt_EndsWith)
                    .addComponent(bt_SubString))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_toLowerCase)
                    .addComponent(bt_Replace))
                .addGap(18, 18, 18)
                .addComponent(bt_IndexOf)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bt_LastIndexOf)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_EqualsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_EqualsActionPerformed
        
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
        
       System.out.println("st1="+st1);
       System.out.println("st2="+st2);
       
       if(st1.equals(st2)) {
           JOptionPane.showMessageDialog(null, "AS Strings São Iguais!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
       } else {
           JOptionPane.showMessageDialog(null, "AS Strings NÃO São Iguais!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
       }
       
    }//GEN-LAST:event_bt_EqualsActionPerformed

    private void bt_EqualsIgnoreCaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_EqualsIgnoreCaseActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
        
       if(st1.equalsIgnoreCase(st2)) {
           JOptionPane.showMessageDialog(null, "AS Strings São Iguais!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
       } else {
           JOptionPane.showMessageDialog(null, "AS Strings NÃO São Iguais!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
       }
       
    }//GEN-LAST:event_bt_EqualsIgnoreCaseActionPerformed

    private void bt_isEmptyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_isEmptyActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       if(st1.isEmpty()) {
           JOptionPane.showMessageDialog(null, "String1 está vazia", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
       }
       if(st2.isEmpty()) {
           JOptionPane.showMessageDialog(null, "String2 está vazia", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
       }
    }//GEN-LAST:event_bt_isEmptyActionPerformed

    private void bt_toUpperCaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_toUpperCaseActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       msg = "String1 em UpperCase:"+st1.toUpperCase();
       msg = msg + "\nString2 em UpperCase:"+st2.toUpperCase();
       
       JOptionPane.showMessageDialog(null, msg, "Resultado toUpperCase", JOptionPane.PLAIN_MESSAGE);
       
    }//GEN-LAST:event_bt_toUpperCaseActionPerformed

    private void bt_toLowerCaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_toLowerCaseActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       msg = "String1 em LowerCase:"+st1.toLowerCase();
       msg = msg + "\nString2 em LowerCase:"+st2.toLowerCase();
       
       JOptionPane.showMessageDialog(null, msg, "Resultado toLowerCase", JOptionPane.PLAIN_MESSAGE);
        
        
    }//GEN-LAST:event_bt_toLowerCaseActionPerformed

    private void bt_StartsWith1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_StartsWith1ActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       if(st1.startsWith(st2)) {
           JOptionPane.showMessageDialog(null, "String1 começa com String2", "Resultado StartsWith",JOptionPane.PLAIN_MESSAGE);
       } else {
           JOptionPane.showMessageDialog(null, "String1 NÃO começa com String2", "Resultado StartsWith",JOptionPane.PLAIN_MESSAGE);
       }
       
    }//GEN-LAST:event_bt_StartsWith1ActionPerformed

    private void bt_EndsWithActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_EndsWithActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       if(st1.endsWith(st2)) {
           JOptionPane.showMessageDialog(null, "String1 termina com String2", "Resultado EndsWith",JOptionPane.PLAIN_MESSAGE);
       } else {
           JOptionPane.showMessageDialog(null, "String1 NÃO termina com String2", "Resultado EndsWith",JOptionPane.PLAIN_MESSAGE);
       }
    }//GEN-LAST:event_bt_EndsWithActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       msg = "A String1 tem "+ st1.length()+" caracteres.";
       msg = msg + "\nA String2 tem "+ st2.length()+" caracteres.";
       
       JOptionPane.showMessageDialog(null, msg, "Resultado do Length", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void bt_ReplaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_ReplaceActionPerformed
       
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
      
       c1 = tf_c1.getText().trim().charAt(0);
       c2 = tf_c2.getText().trim().charAt(0);
       
      
       msg = "A String1 com Replace"+  st1.replace(c1, c2)+".";
       msg = msg + "\nA String2 com Replace "+ st2.replace(c1, c2)+".";
       
       JOptionPane.showMessageDialog(null, msg, "Resultado do Replace", JOptionPane.PLAIN_MESSAGE);
       
    }//GEN-LAST:event_bt_ReplaceActionPerformed

    private void bt_IndexOfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_IndexOfActionPerformed
       
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       c1 = tf_c1.getText().trim().charAt(0);
       c2 = tf_c2.getText().trim().charAt(0);
       
       
       st1.indexOf(c2);
       msg = "O Caractere c1 esta em: "+  st1.indexOf(c1) +" da String1";
       msg = msg + "\nO Caractere c2 esta em: "+  st2.indexOf(c2) +" da String2";
       
       
       JOptionPane.showMessageDialog(null, msg, "Resultado do IndexOf", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_bt_IndexOfActionPerformed

    private void bt_LastIndexOfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_LastIndexOfActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       c1 = tf_c1.getText().trim().charAt(0);
       c2 = tf_c2.getText().trim().charAt(0);
       
       
    
       msg = "O Caractere c1 esta em: "+  st1.lastIndexOf(c1) +" da String1";
       msg = msg + "\nO Caractere c2 esta em: "+  st2.lastIndexOf(c2) +" da String2";
       
       
       JOptionPane.showMessageDialog(null, msg, "Resultado do lastIndexOf", JOptionPane.PLAIN_MESSAGE); 
    }//GEN-LAST:event_bt_LastIndexOfActionPerformed

    private void bt_SubStringActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_SubStringActionPerformed
       st1 = tf_St1.getText().trim();
       st2 = tf_St2.getText().trim();
       
       
       
       
       int i1 =  Integer.parseInt(tf_c1.getText().trim());
       int i2 =  Integer.parseInt(tf_c2.getText().trim());
               
       msg = "Resultado de st1=" + st1.substring(i1, i2);
       msg = msg + "\nResultado de st2=" + st2.substring(i1, i2);
       
       JOptionPane.showMessageDialog(null, msg, "Resultado do SubString", JOptionPane.PLAIN_MESSAGE); 
       
       
    }//GEN-LAST:event_bt_SubStringActionPerformed

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new fr_TelaString().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_EndsWith;
    private javax.swing.JButton bt_Equals;
    private javax.swing.JButton bt_EqualsIgnoreCase;
    private javax.swing.JButton bt_IndexOf;
    private javax.swing.JButton bt_LastIndexOf;
    private javax.swing.JButton bt_Replace;
    private javax.swing.JButton bt_StartsWith1;
    private javax.swing.JButton bt_SubString;
    private javax.swing.JButton bt_isEmpty;
    private javax.swing.JButton bt_toLowerCase;
    private javax.swing.JButton bt_toUpperCase;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel lb_St1;
    private javax.swing.JLabel lb_St2;
    private javax.swing.JLabel lb_c1;
    private javax.swing.JLabel lb_c2;
    private javax.swing.JTextField tf_St1;
    private javax.swing.JTextField tf_St2;
    private javax.swing.JTextField tf_c1;
    private javax.swing.JTextField tf_c2;
    // End of variables declaration//GEN-END:variables
}
