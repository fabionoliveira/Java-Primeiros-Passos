/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg;

/**
 *
 * @author FO
 */
public class Tab_Celular {

    private int cod_Celular;
    private String nr_celular;

    public int getCod_Celular() {
        return cod_Celular;
    }

    public void setCod_Celular(int cod_Celular) {
        this.cod_Celular = cod_Celular;
    }

    public String getNr_celular() {
        return nr_celular;
    }

    public void setNr_celular(String nr_celular) {
        this.nr_celular = nr_celular;
    }

}
