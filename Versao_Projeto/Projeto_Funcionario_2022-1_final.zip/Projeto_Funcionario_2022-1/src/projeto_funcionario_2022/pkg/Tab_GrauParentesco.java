/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg;

/**
 *
 * @author FO
 */
public class Tab_GrauParentesco {

    private int cod_GrauParentesco;
    private String ds_GrauParentesco;

    public int getCod_GrauParentesco() {
        return cod_GrauParentesco;
    }

    public void setCod_GrauParentesco(int cod_GrauParentesco) {
        this.cod_GrauParentesco = cod_GrauParentesco;
    }

    public String getDs_GrauParentesco() {
        return ds_GrauParentesco;
    }

    public void setDs_GrauParentesco(String ds_GrauParentesco) {
        this.ds_GrauParentesco = ds_GrauParentesco;
    }

    

      
}
