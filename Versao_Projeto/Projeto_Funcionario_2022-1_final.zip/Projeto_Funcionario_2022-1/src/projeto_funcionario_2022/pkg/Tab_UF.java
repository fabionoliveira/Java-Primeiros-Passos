/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg;

/**
 *
 * @author Aluno
 */
public class Tab_UF {
    
    private int cod_UF;
    private String nm_UF;
    private String abr_UF;

    public int getCod_UF() {
        return cod_UF;
    }

    public void setCod_UF(int cod_UF) {
        this.cod_UF = cod_UF;
    }

    public String getNm_UF() {
        return nm_UF;
    }

    public void setNm_UF(String nm_UF) {
        this.nm_UF = nm_UF;
    }

    public String getAbr_UF() {
        return abr_UF;
    }

    public void setAbr_UF(String abr_UF) {
        this.abr_UF = abr_UF;
    }
    
}
