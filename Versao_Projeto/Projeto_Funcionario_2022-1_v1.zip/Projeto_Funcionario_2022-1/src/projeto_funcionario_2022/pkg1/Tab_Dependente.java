/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg1;

/**
 *
 * @author FO
 */
public class Tab_Dependente extends Tab_Funcionario{
    
    private int cod_Dependente;
    //private String nm_Funcionario;
    protected String nm_Dependente;
    private String dt_NasDependente;
    private String rg_Dependente;
    private String cpf_Dependente;
    private String gen_Dependente;
    private String grau_Parentesco_Dependente;

    public int getCod_Dependente() {
        return cod_Dependente;
    }

    public void setCod_Dependente(int cod_Dependente) {
        this.cod_Dependente = cod_Dependente;
    }

    public String getNm_Dependente() {
        return nm_Dependente;
    }

    public void setNm_Dependente(String nm_Dependente) {
        this.nm_Dependente = nm_Dependente;
    }

    public String getDt_NasDependente() {
        return dt_NasDependente;
    }

    public void setDt_NasDependente(String dt_NasDependente) {
        this.dt_NasDependente = dt_NasDependente;
    }

    public String getRg_Dependente() {
        return rg_Dependente;
    }

    public void setRg_Dependente(String rg_Dependente) {
        this.rg_Dependente = rg_Dependente;
    }

    public String getCpf_Dependente() {
        return cpf_Dependente;
    }

    public void setCpf_Dependente(String cpf_Dependente) {
        this.cpf_Dependente = cpf_Dependente;
    }

    public String getGen_Dependente() {
        return gen_Dependente;
    }

    public void setGen_Dependente(String gen_Dependente) {
        this.gen_Dependente = gen_Dependente;
    }

    public String getGrau_Parentesco_Dependente() {
        return grau_Parentesco_Dependente;
    }

    public void setGrau_Parentesco_Dependente(String grau_Parentesco_Dependente) {
        this.grau_Parentesco_Dependente = grau_Parentesco_Dependente;
    }

    
    
}
