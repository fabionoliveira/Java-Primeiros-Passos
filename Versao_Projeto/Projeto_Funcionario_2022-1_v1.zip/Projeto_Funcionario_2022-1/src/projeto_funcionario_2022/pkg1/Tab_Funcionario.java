/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg1;

/**
 *
 * @author FO
 */
public class Tab_Funcionario {
    
    private   int    cod_Funcionario;
    private   String nm_Funcionario;
    private   String dt_Nascimento;
    protected String rg;
    protected String cpf;
    private   String ds_Endereco;
    protected String ds_Cidade;
    protected String ds_Genero;
    protected String ds_Departamento;
    protected String ds_Cargo;

    public int getCod_Funcionario() {
        return cod_Funcionario;
    }

    public void setCod_Funcionario(int cod_Funcionario) {
        this.cod_Funcionario = cod_Funcionario;
    }

    public String getNm_Funcionario() {
        return nm_Funcionario;
    }

    public void setNm_Funcionario(String nm_Funcionario) {
        this.nm_Funcionario = nm_Funcionario;
    }

    public String getDt_Nascimento() {
        return dt_Nascimento;
    }

    public void setDt_Nascimento(String dt_Nascimento) {
        this.dt_Nascimento = dt_Nascimento;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDs_Endereco() {
        return ds_Endereco;
    }

    public void setDs_Endereco(String ds_Endereco) {
        this.ds_Endereco = ds_Endereco;
    }

    public String getDs_Cidade() {
        return ds_Cidade;
    }

    public void setDs_Cidade(String ds_Cidade) {
        this.ds_Cidade = ds_Cidade;
    }

    public String getDs_Genero() {
        return ds_Genero;
    }

    public void setDs_Genero(String ds_Genero) {
        this.ds_Genero = ds_Genero;
    }

    public String getDs_Departamento() {
        return ds_Departamento;
    }

    public void setDs_Departamento(String ds_Departamento) {
        this.ds_Departamento = ds_Departamento;
    }

    public String getDs_Cargo() {
        return ds_Cargo;
    }

    public void setDs_Cargo(String ds_Cargo) {
        this.ds_Cargo = ds_Cargo;
    }
    
   
}
