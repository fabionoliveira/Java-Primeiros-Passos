/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_funcionario_2022.pkg1;

/**
 *
 * @author FO
 */
public class Tab_TelResidencial {
    
    private int cod_TelResidencial;
    private String nr_TelResidencial;

    public int getCod_TelResidencial() {
        return cod_TelResidencial;
    }

    public void setCod_TelResidencial(int cod_TelResidencial) {
        this.cod_TelResidencial = cod_TelResidencial;
    }

    public String getNr_TelResidencial() {
        return nr_TelResidencial;
    }

    public void setNr_TelResidencial(String nr_TelResidencial) {
        this.nr_TelResidencial = nr_TelResidencial;
    }
    
    
}
