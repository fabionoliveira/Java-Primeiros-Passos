
package lp02_22_1_m_cadusuario;

import javax.swing.JOptionPane;


public class fr_CadUsuario extends javax.swing.JFrame {

     String TipoUsuario;
    
    public fr_CadUsuario() {
        initComponents();
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb_Id = new javax.swing.JLabel();
        tf_Id = new javax.swing.JTextField();
        lb_Nome = new javax.swing.JLabel();
        tf_Nome = new javax.swing.JTextField();
        lb_Login = new javax.swing.JLabel();
        tf_Login = new javax.swing.JTextField();
        lb_TipoUser = new javax.swing.JLabel();
        rb_Administrador = new javax.swing.JRadioButton();
        rb_Funcionario = new javax.swing.JRadioButton();
        lb_Permissoes = new javax.swing.JLabel();
        ckb_RelatoriosGerais = new javax.swing.JCheckBox();
        ckb_RelatoriosAnaliticos = new javax.swing.JCheckBox();
        ckb_CadastroUsuarios = new javax.swing.JCheckBox();
        rb_Visitante = new javax.swing.JRadioButton();
        ckb_PontoEletronico = new javax.swing.JCheckBox();
        lb_Genero = new javax.swing.JLabel();
        cb_Genero = new javax.swing.JComboBox<>();
        lb_Limpar = new javax.swing.JButton();
        bt_Valida = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro de Usuários");

        lb_Id.setText("Id:");

        lb_Nome.setText("Nome:");

        lb_Login.setText("Login:");

        lb_TipoUser.setText("Tipo User:");

        rb_Administrador.setText("Administrador");
        rb_Administrador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_AdministradorActionPerformed(evt);
            }
        });

        rb_Funcionario.setText("Funioário");
        rb_Funcionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_FuncionarioActionPerformed(evt);
            }
        });

        lb_Permissoes.setText("Permissões:");

        ckb_RelatoriosGerais.setText("Relatórios Gerais");

        ckb_RelatoriosAnaliticos.setText("Relatórios Analíticos");

        ckb_CadastroUsuarios.setText("Cadastro Usuários");

        rb_Visitante.setText("Visitante");
        rb_Visitante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_VisitanteActionPerformed(evt);
            }
        });

        ckb_PontoEletronico.setText("Ponto Eletrônico");

        lb_Genero.setText("Gênero:");

        cb_Genero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Feminino", "Masculino", "Não Informado" }));
        cb_Genero.setSelectedIndex(-1);

        lb_Limpar.setText("Limpar");

        bt_Valida.setText("Valida");
        bt_Valida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_ValidaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lb_Nome)
                                    .addComponent(lb_Id))
                                .addGap(44, 44, 44)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tf_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tf_Id, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lb_TipoUser)
                                    .addComponent(lb_Permissoes)
                                    .addComponent(lb_Genero)
                                    .addComponent(lb_Login))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ckb_RelatoriosGerais)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rb_Administrador)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(rb_Funcionario)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(rb_Visitante))
                                    .addComponent(ckb_RelatoriosAnaliticos)
                                    .addComponent(ckb_CadastroUsuarios)
                                    .addComponent(ckb_PontoEletronico)
                                    .addComponent(cb_Genero, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tf_Login, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(58, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lb_Limpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt_Valida)
                        .addGap(182, 182, 182))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_Id)
                    .addComponent(tf_Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_Nome)
                    .addComponent(tf_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_Login)
                    .addComponent(tf_Login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_TipoUser)
                    .addComponent(rb_Administrador)
                    .addComponent(rb_Funcionario)
                    .addComponent(rb_Visitante))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_Permissoes)
                    .addComponent(ckb_RelatoriosGerais))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ckb_RelatoriosAnaliticos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ckb_CadastroUsuarios)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ckb_PontoEletronico)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_Genero)
                    .addComponent(cb_Genero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_Limpar)
                    .addComponent(bt_Valida)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rb_AdministradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_AdministradorActionPerformed
        setTipoUsuario( true, false, false);
    }//GEN-LAST:event_rb_AdministradorActionPerformed

    private void rb_FuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_FuncionarioActionPerformed
        setTipoUsuario( false,  true, false);
    }//GEN-LAST:event_rb_FuncionarioActionPerformed

    private void rb_VisitanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_VisitanteActionPerformed
        
    }//GEN-LAST:event_rb_VisitanteActionPerformed

    private void bt_ValidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_ValidaActionPerformed
        
        if (!ValidaNome ()) {
            JOptionPane.showMessageDialog(null, "Nome deve ter entre 5 e 40 caracteres.", "Validação Tela", JOptionPane.ERROR_MESSAGE);
        }
       
        if (!ValidaLogin())  {
            
            JOptionPane.showMessageDialog(null, "O Login deve ter entre 5 e 12 caracteres.", "Validação Tela", JOptionPane.ERROR_MESSAGE);
        }
        
        if (!ValidaTipoPermissao()) {
            JOptionPane.showMessageDialog(null, "Selecione ao menos uma permissão.", "Validação Tela", JOptionPane.ERROR_MESSAGE);
        }
        
        if (!ValidaTipoUsuario()) {
            JOptionPane.showMessageDialog(null, "Selecione UM tipo de Usuário.", "Validação Tela", JOptionPane.ERROR_MESSAGE);
        }
        
        if (cb_Genero.getSelectedIndex()==-1) {
            JOptionPane.showMessageDialog(null, "Selecione UM Gênero para o  Usuário.", "Validação Tela", JOptionPane.ERROR_MESSAGE);
        }
        
        if (rb_Administrador.isSelected()) { TipoUsuario = "ADM";}
        else if (rb_Funcionario.isSelected()) { TipoUsuario = "FUNC";} 
              else { TipoUsuario = "VISITANTE";} 
        
        String Permissoes ="";
        
        if (ckb_CadastroUsuarios.isSelected()) { Permissoes = "CadUsuário";}
        if (ckb_PontoEletronico.isSelected()) {  Permissoes = Permissoes + " POntoEletrocino";}
        if (ckb_RelatoriosGerais.isSelected()) {  Permissoes = Permissoes + " RelatoriosGerais";}
        if (ckb_RelatoriosAnaliticos.isSelected()) {  Permissoes = Permissoes + " RelatoriosAnaliticos";}
        
        String msg = "Relatório";
        msg = msg + "\nNome:       " + tf_Nome.getText().trim();
        msg = msg + "\nLogin:      " + tf_Login.getText().trim();
        msg = msg + "\nGenero:     " + cb_Genero.getSelectedItem().toString();
        msg = msg + "\nTipoUsuario:" + TipoUsuario;
        msg = msg + "\nPermissões: " + Permissoes;
        
    
        JOptionPane.showConfirmDialog(null, msg);
                
        
    }//GEN-LAST:event_bt_ValidaActionPerformed

   
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new fr_CadUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_Valida;
    private javax.swing.JComboBox<String> cb_Genero;
    private javax.swing.JCheckBox ckb_CadastroUsuarios;
    private javax.swing.JCheckBox ckb_PontoEletronico;
    private javax.swing.JCheckBox ckb_RelatoriosAnaliticos;
    private javax.swing.JCheckBox ckb_RelatoriosGerais;
    private javax.swing.JLabel lb_Genero;
    private javax.swing.JLabel lb_Id;
    private javax.swing.JButton lb_Limpar;
    private javax.swing.JLabel lb_Login;
    private javax.swing.JLabel lb_Nome;
    private javax.swing.JLabel lb_Permissoes;
    private javax.swing.JLabel lb_TipoUser;
    private javax.swing.JRadioButton rb_Administrador;
    private javax.swing.JRadioButton rb_Funcionario;
    private javax.swing.JRadioButton rb_Visitante;
    private javax.swing.JTextField tf_Id;
    private javax.swing.JTextField tf_Login;
    private javax.swing.JTextField tf_Nome;
    // End of variables declaration//GEN-END:variables

    
private boolean ValidaTipoUsuario () {
    boolean saida=true;
    if ((!rb_Administrador.isSelected())&&
        (!rb_Funcionario.isSelected())&&            
        (!rb_Visitante.isSelected())
       )    
    { 
        saida=false;
    }
    return saida;
}
    
private boolean ValidaTipoPermissao () {
    boolean saida=true;
    if ((!ckb_CadastroUsuarios.isSelected())&&
        (!ckb_PontoEletronico.isSelected())&&    
        (!ckb_RelatoriosAnaliticos.isSelected())&&    
        (!ckb_RelatoriosGerais.isSelected())
       )    
    { 
        saida=false;
    }
    return saida;
}    

    
private boolean ValidaLogin () {
    boolean saida=true;
    if ((tf_Login.getText().trim().length()<5)||(tf_Login.getText().trim().length()>12)) {
        saida=false;
    }
    return saida;
}    

    
private boolean ValidaNome () {
    boolean saida=true;
    if ((tf_Nome.getText().trim().length()<5)||(tf_Nome.getText().trim().length()>40)) {
        saida=false;
    }
    return saida;
}    
    
    
 private void setTipoUsuario (boolean adm, boolean func, boolean vis) {
        rb_Administrador.setSelected(adm);
        rb_Funcionario.setSelected(func);
        rb_Visitante.setSelected(vis);
    }


}//////////////////////////////////////////////////////////////////////////////////////////////////////////
