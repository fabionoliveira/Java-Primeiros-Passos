
package lp02_22_1_m_cadusuario;


public class LP02_22_1_m_CadUsuario {

   
    public static void main(String[] args) {
        
        fr_CadUsuario   myTela = new  fr_CadUsuario ();
        
        myTela.setVisible(true);
    }
    
}
