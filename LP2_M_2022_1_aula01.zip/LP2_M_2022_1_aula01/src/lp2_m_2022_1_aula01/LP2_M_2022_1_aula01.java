
package lp2_m_2022_1_aula01;


public class LP2_M_2022_1_aula01 {

    
    public static void main(String[] args) {
        
        
    }
    
}
